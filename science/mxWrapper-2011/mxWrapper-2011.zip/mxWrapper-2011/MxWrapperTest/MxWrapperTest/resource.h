//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MxWrapperTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDR_MAINFRAME                   128
#define IDR_MxWrapperTestTYPE           129
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_CPLOT                       1002
#define IDC_CPLOT2                      1003
#define IDC_BUTTON_EVAL                 1004
#define IDC_EDIT_SNR                    1005
#define IDC_COMBO1                      1006
#define IDC_EDIT4                       1007
#define IDC_EDIT_CUTOFF                 1007
#define ID_FILE_START                   32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
