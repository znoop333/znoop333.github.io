// DlgAreaPlot.cpp : implementation file
//

#include "stdafx.h"
#include "MxWrapperTest.h"
#include "DlgAreaPlot.h"


// CDlgAreaPlot

IMPLEMENT_DYNAMIC(CDlgAreaPlot, CStatic)

CDlgAreaPlot::CDlgAreaPlot()
{

}

CDlgAreaPlot::~CDlgAreaPlot()
{
}


BEGIN_MESSAGE_MAP(CDlgAreaPlot, CStatic)
	ON_WM_DRAWITEM()
END_MESSAGE_MAP()



// CDlgAreaPlot message handlers



void CDlgAreaPlot::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
1;
	// TODO:  Add your code to draw the specified item
}
