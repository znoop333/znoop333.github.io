//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CPlotResources.rc
//
#define IDR_CT_FIRST                    10033
#define IDR_CT_BWLINEAR                 10033
#define IDR_CT_RAINBOW                  10034
#define IDR_CT_REDTEMPERATURE           10035
#define IDR_CT_16LEVEL                  10036
#define IDR_CT_BEACH                    10037
#define IDR_CT_BLUEPASTELRED            10038
#define IDR_CT_BLUEWAVES                10039
#define IDR_CT_BLUERED                  10040
#define IDR_CT_EOSA                     10041
#define IDR_CT_EOSB                     10042
#define IDR_CT_GREENPINK                10043
#define IDR_CT_GREENREDBLUEWHITE        10044
#define IDR_CT_HARDCANDY                10045
#define IDR_CT_HAZE                     10046
#define IDR_CT_HSV1                     10047
#define IDR_CT_HSV2                     10048
#define IDR_CT_MACSTYLE                 10049
#define IDR_CT_NATURE                   10050
#define IDR_CT_OCEAN                    10051
#define IDR_CT_PASTELS                  10052
#define IDR_CT_PEPPERMINT               10053
#define IDR_CT_PLASMA                   10054
#define IDR_CT_PRISM                    10055
#define IDR_CT_PURPLEREDSTRIPES         10056
#define IDR_CT_RAINBOW18                10057
#define IDR_CT_RAINBOWBLACK             10058
#define IDR_CT_RAINBOWWHITE             10059
#define IDR_CT_REDPURPLE                10060
#define IDR_CT_STDGAMMAII               10061
#define IDR_CT_STEPS                    10062
#define IDR_CT_STERNSPECIAL             10063
#define IDR_CT_VOLCANO                  10064
#define IDR_CT_WAVES                    10065
#define IDD_XY_SETTINGS                 10068
#define IDD_AXIS_SETTINGS               10071
#define IDD_DATA_SETTINGS               10072
#define IDD_IMAGE_SETTINGS              10073
#define IDC_PS_XRANGE_LOW               11001
#define IDC_PS_XRANGE_HIGH              11002
#define IDC_PS_YRANGE_LOW               11003
#define IDC_PS_YRANGE_HIGH              11004
#define IDC_PS_AUTO_XRANGE              11005
#define IDC_PS_AUTO_YRANGE              11006
#define IDC_PS_MAJOR_HORIZONTAL_GRIDS   11007
#define IDC_MINOR_HORIZONTAL_GRIDS      11008
#define IDC_PS_MAJOR_VERTICAL_GRIDS     11009
#define IDC_MINOR_VERTICAL_GRIDS        11010
#define IDC_PS_COLOR_MAJOR_GRIDS        11011
#define IDC_PS_COLOR_MINOR_GRIDS        11013
#define IDC_PS_COLOR_TITLE_FONT         11015
#define IDC_PS_PLOT_TITLE               11016
#define IDC_PS_TITLE_FONT               11017
#define IDC_AS_LABEL_FONT               11018
#define IDC_PS_CHOOSE_TITLE_FONT        11018
#define IDC_PS_COLOR_BACKGROUND         11019
#define IDC_AXIS_PREVIOUS               11020
#define IDC_PS_COLOR_BORDER             11020
#define IDC_AXIS_NEXT                   11021
#define IDC_AXIS_LABEL                  11022
#define IDC_NUMBER_MAJOR_TICKS          11023
#define IDC_AS_NUMBER_MINOR_TICKS       11024
#define IDC_AS_AUTO_MAJOR_TICKS         11025
#define IDC_AS_AUTO_MINOR_TICKS         11026
#define IDC_AS_AUTO_XRANGE              11027
#define IDC_AS_XRANGE_HIGH              11028
#define IDC_AS_XRANGE_LOW               11029
#define IDC_AS_PLOT_TITLE               11030
#define IDC_AS_CHOOSE_TITLE_FONT        11031
#define IDC_AS_COLOR_TITLE_FONT         11032
#define IDC_AS_COLOR_LINE               11033
#define IDC_AS_MAJOR_TICK_LENGTH        11034
#define IDC_AS_MINOR_TICK_LENGTH        11035
#define IDC_DS_DATA_TITLE               11036
#define IDC_AS_CHOOSE_LABEL_FONT        11037
#define IDC_DS_COLOR_LINE               11038
#define IDC_MARKER_SIZE                 11043
#define IDC_MARKER_FREQUENCY_EVERY      11044
#define IDC_MARKER_FREQUENCY_NTH        11045
#define IDC_MARKER_FREQUENCY_NUMBER     11046
#define IDC_MARKER_FREQUENCY_TOTAL      11047
#define IDC_MARKER_FREQUENCY_TOTAL_DATA 11048
#define IDC_MARKER_SHAPE                11050
#define IDC_CHART_TYPE                  11051
#define IDC_DATA_NEXT                   11052
#define IDC_DATA_PREVIOUS               11053
#define IDC_DATASET_LABEL               11054
#define IDC_PLOT_TO_SIZE                11055
#define IDC_MAINTAIN_ASPECT_RATIO       11056
#define IDC_MAJOR_GRID_SIZE             11057
#define IDC_DATA_LINE_SIZE              11058
#define IDC_MINOR_GRID_SIZE             11058
#define IDS_COLOR_TABLES                12000
#define IDS_COLOR_TABLE_ID              12001
#define IDC_DATA_MARKER_FILL            50000
#define IDC_DATA_LINESTYLE              50001
#define IDC_PLOT_MAJOR_LINESTYLE		50002
#define IDC_PLOT_MINOR_LINESTYLE        50003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        12001
#define _APS_NEXT_COMMAND_VALUE         56100
#define _APS_NEXT_CONTROL_VALUE         50003
#define _APS_NEXT_SYMED_VALUE           50000
#endif
#endif
